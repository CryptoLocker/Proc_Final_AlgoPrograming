// Autor: Andres Ariza ~ Jhaynner Vargas
package MazeGame2;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class App {

    static int[] posicionJugador = {-1, -1}; // Posición inicial del jugador en el laberinto
    static int[][] mapaActual; // Matriz que representa el laberinto actual
    static JButton[][] botones; // Matriz de botones en la interfaz gráfica

    // Definición de colores para elementos del laberinto
    static Color colorMuro = Color.black;
    static Color colorPiso = Color.white;
    static Color colorJugador = Color.red;
    static Color colorMeta = Color.green;

    // Definición de varios mapas adicionales
    static int[][][] mapasAdicionales = {
        {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 2, 0, 0, 0, 0, 1},
            {1, 0, 1, 0, 1, 0, 1, 0, 0, 1},
            {1, 0, 1, 1, 1, 0, 1, 1, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 0, 1, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 3, 1}
        },
        {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 2, 0, 0, 0, 1, 0, 0, 0, 1},
            {1, 0, 1, 0, 0, 1, 0, 1, 0, 1},
            {1, 0, 1, 1, 1, 1, 0, 1, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 1, 0, 1},
            {1, 1, 1, 0, 1, 1, 1, 1, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 1, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 3, 0, 1}
        },
        {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 2, 1, 0, 1, 0, 0, 1},
            {1, 0, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 1, 1, 1, 0, 1, 1},
            {1, 0, 1, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 0, 0, 1, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 3, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
        },
        {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 1, 1, 1, 1, 1, 0, 1, 1},
            {1, 0, 1, 0, 0, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 1, 0, 1, 0, 0, 1},
            {1, 0, 1, 0, 1, 0, 1, 1, 0, 1},
            {1, 0, 1, 2, 1, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 3, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
        },
        {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 2, 0, 0, 1, 0, 0, 0, 0, 1},
            {1, 0, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 1, 0, 0, 0, 0, 1, 0, 1},
            {1, 0, 1, 1, 1, 1, 0, 1, 0, 1},
            {1, 0, 0, 0, 0, 1, 0, 1, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 0, 1, 1, 0, 1, 0, 3, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
        },
        {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 1, 0, 0, 0, 0, 1},
            {1, 0, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 1, 0, 0, 0, 0, 1, 0, 1},
            {1, 0, 1, 1, 1, 1, 0, 1, 0, 1},
            {1, 0, 0, 0, 0, 1, 0, 1, 0, 1},
            {1, 1, 0, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 0, 1, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 1, 1, 0, 1, 0, 3, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
        },
        {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 0, 1, 1, 1, 0, 1, 0, 1},
            {1, 0, 0, 0, 0, 1, 0, 1, 0, 1},
            {1, 0, 1, 1, 0, 1, 1, 1, 0, 1},
            {1, 0, 1, 0, 0, 0, 0, 1, 0, 1},
            {1, 0, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 1, 1, 0, 1, 0, 0, 3, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
        },
        {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 1, 1, 1, 1, 1, 0, 1, 1},
            {1, 0, 1, 0, 0, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 1, 0, 1, 0, 0, 1},
            {1, 0, 1, 0, 1, 0, 1, 1, 0, 1},
            {1, 0, 0, 0, 1, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 2, 0, 0, 0, 0, 0, 0, 3, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
        },
        {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 1, 0, 0, 0, 0, 1},
            {1, 0, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 1, 0, 0, 0, 0, 1, 0, 1},
            {1, 0, 1, 1, 1, 1, 0, 1, 0, 1},
            {1, 0, 0, 0, 0, 1, 0, 1, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 2, 0, 1, 1, 0, 1, 0, 3, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}
        },
        {
            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 1, 0, 1, 0, 0, 1},
            {1, 0, 1, 0, 1, 0, 1, 0, 1, 1},
            {1, 0, 1, 0, 1, 1, 1, 0, 1, 1},
            {1, 0, 1, 0, 0, 0, 0, 0, 0, 1},
            {1, 0, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
            {1, 1, 1, 1, 1, 1, 1, 1, 0, 1},
            {1, 0, 0, 0, 0, 0, 0, 0, 3, 1},
            {1, 1, 1, 1, 1, 1, 1, 2, 1, 1}
        },};

    public static void main(String[] args) {
        iniciarJuego();
    }

    static void iniciarJuego() {
        JFrame ventana = new JFrame();
        ventana.setSize(400, 400);
        ventana.setTitle("Laberinto");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setLocationRelativeTo(null);

        seleccionarMapaAleatorio();

        botones = new JButton[mapaActual.length][mapaActual[0].length];

        // Configuración de la interfaz gráfica según el laberinto actual
        for (int i = 0; i < mapaActual.length; i++) {
            for (int j = 0; j < mapaActual[0].length; j++) {
                JButton btn = new JButton();

                // Asignar colores a los botones según el tipo de celda en el laberinto
                if (mapaActual[i][j] == 0) {
                    btn.setBackground(colorPiso);
                } else if (mapaActual[i][j] == 1) {
                    btn.setBackground(colorMuro);
                } else if (mapaActual[i][j] == 2) {
                    btn.setBackground(colorJugador);
                    posicionJugador[0] = i;
                    posicionJugador[1] = j;
                } else if (mapaActual[i][j] == 3) {
                    btn.setBackground(colorMeta);
                }

                // Configurar ActionListener para manejar clics en los botones
                btn.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JButton clickBoton = (JButton) e.getSource();
                        Color botonColor = clickBoton.getBackground();

                        // Lógica para manejar acciones según el tipo de celda en el laberinto
                        if (botonColor.equals(colorPiso)) {
                            movimientoDelJugador(clickBoton);
                        } else if (botonColor.equals(colorMuro)) {
                            JOptionPane.showMessageDialog(null, "Esto es un muro, no puedes pasar.");
                        } else if (botonColor.equals(colorJugador)) {
                            JOptionPane.showMessageDialog(null, "Este eres tú.");
                        } else if (botonColor.equals(colorMeta)) {
                            movimientoDelJugador(clickBoton);
                            btn.setBackground(colorMeta);
                            JOptionPane.showMessageDialog(null, "¡Has ganado!");
                            System.exit(0);
                        }
                    }
                });
                ventana.add(btn);
                botones[i][j] = btn;
            }
        }
        // Configurar botones adicionales para iniciar y reiniciar el juego
        JButton startButton = new JButton("Empezar");
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resolverLaberinto();
            }
        });
        ventana.add(startButton);

        JButton nuevoJuegoButton = new JButton("Nuevo Juego");
        nuevoJuegoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                seleccionarMapaAleatorio();
                reiniciarJuego();
            }
        });
        ventana.add(nuevoJuegoButton);

        // Configurar diseño de la ventana
        ventana.setLayout(new GridLayout(mapaActual.length, mapaActual[0].length + 2));
        ventana.setVisible(true);
    }

    static void seleccionarMapaAleatorio() {
        Random rand = new Random();
        int indiceMapa = rand.nextInt(mapasAdicionales.length);
        mapaActual = mapasAdicionales[indiceMapa];
    }

    static boolean esPosicionValida(int i, int j) {
        return i >= 0 && i < mapaActual.length && j >= 0 && j < mapaActual[0].length;
    }

    static void reiniciarJuego() {
        for (int i = 0; i < mapaActual.length; i++) {
            for (int j = 0; j < mapaActual[0].length; j++) {
                JButton btn = botones[i][j];
                if (mapaActual[i][j] == 0) {
                    btn.setBackground(colorPiso);
                } else if (mapaActual[i][j] == 1) {
                    btn.setBackground(colorMuro);
                } else if (mapaActual[i][j] == 2) {
                    btn.setBackground(colorJugador);
                    posicionJugador[0] = i;
                    posicionJugador[1] = j;
                } else if (mapaActual[i][j] == 3) {
                    btn.setBackground(colorMeta);
                }
            }
        }
    }

    static void movimientoDelJugador(JButton clickBoton) {
        int[] posicionDelClickBoton = obtenerPosicionClickBoton(clickBoton);
        JButton jugadorBoton = botones[posicionJugador[0]][posicionJugador[1]];
        Color colorClickBoton = clickBoton.getBackground();

        if (esMovimientoValido(posicionDelClickBoton)) {
            if (colorClickBoton.equals(colorPiso)) {
                jugadorBoton.setBackground(colorPiso);
                clickBoton.setBackground(colorJugador);
                posicionJugador[0] = posicionDelClickBoton[0];
                posicionJugador[1] = posicionDelClickBoton[1];
            } else if (colorClickBoton.equals(colorMeta)) {
                JOptionPane.showMessageDialog(null, "¡Has ganado!");
                System.exit(0);
            }
        } else {
            JOptionPane.showMessageDialog(null, "No está permitido mover más de un espacio por clic.");
        }
    }

    static boolean esMovimientoValido(int[] posicionDelClickBoton) {
        return Math.abs(posicionJugador[0] - posicionDelClickBoton[0]) < 2
                && Math.abs(posicionJugador[1] - posicionDelClickBoton[1]) < 2;
    }

    static int[] obtenerPosicionClickBoton(JButton clickBoton, int i, int j) {
        if (i < botones.length) {
            if (j < botones[0].length) {
                if (botones[i][j].equals(clickBoton)) {
                    return new int[]{i, j};
                }
                return obtenerPosicionClickBoton(clickBoton, i, j + 1);
            }
            return obtenerPosicionClickBoton(clickBoton, i + 1, 0);
        }
        return new int[]{-1, -1};
    }

    static int[] obtenerPosicionClickBoton(JButton clickBoton) {
        return obtenerPosicionClickBoton(clickBoton, 0, 0);
    }

    static void resolverLaberinto() {
        boolean[][] visitado = new boolean[mapaActual.length][mapaActual[0].length];
        boolean encontrado = resolverLaberintoRecursivo(posicionJugador[0], posicionJugador[1], visitado);

        if (!encontrado) {
            JOptionPane.showMessageDialog(null, "No hay solución.");
        }
    }

    static boolean resolverLaberintoRecursivo(int i, int j, boolean[][] visitado) {
        if (esPosicionValida(i, j) && !visitado[i][j]) {
            visitado[i][j] = true;
            JButton btn = botones[i][j];

            if (mapaActual[i][j] == 0) {
                btn.setBackground(Color.blue); // Piso visitado
            } else if (mapaActual[i][j] == 3) {
                JOptionPane.showMessageDialog(null, "¡Has encontrado la meta!");
                return true;
            } else if (mapaActual[i][j] == 1) {

                return false;
            }

            if (resolverLaberintoRecursivo(i - 1, j, visitado)
                    || resolverLaberintoRecursivo(i + 1, j, visitado)
                    || resolverLaberintoRecursivo(i, j - 1, visitado)
                    || resolverLaberintoRecursivo(i, j + 1, visitado)) {
                return true;
            }

            btn.setBackground(Color.gray);

            return false;
        }

        return false;
    }
}
